import 'middleware_test.dart' as middleware;
import 'reducer_test.dart' as reducer;
import 'selectors_test.dart' as selector;

main() {
  middleware.main();
  reducer.main();
  selector.main();
}
