import 'package:integration_tests/integration_tests.dart' as integrationTests;

main() {
  integrationTests.main();
}
