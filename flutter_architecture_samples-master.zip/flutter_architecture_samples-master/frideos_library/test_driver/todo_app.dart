import 'package:flutter_driver/driver_extension.dart';
import 'package:frideos_library/main.dart' as app;

void main() {
  enableFlutterDriverExtension();

  app.main();
}
